# KJ Games — Android TV

Aplicativo simples para Android TV com:
- **Dino**: pressione OK/Enter do controle remoto para pular.
- **Cobrinha**: use as setas do controle para mudar a direção.
- Menu navegável por setas e OK; BACK/Escape retorna ao menu.
- Orientação paisagem.

## Compilar APK
O workflow `.github/workflows/build.yml` compila o APK Debug e publica `app-debug.apk` como artefato do GitHub Actions.

1. Envie este projeto para um repositório GitHub.
2. Abra a aba **Actions** e execute **Build KJ Games APK** (ou faça push para main/master).
3. Baixe o artefato **KJ-Games-APK** da execução.

Também pode compilar localmente com JDK 17 e Gradle 8.9:
`gradle assembleDebug`

APK de saída: `app/build/outputs/apk/debug/app-debug.apk`

## Controles
- Menu: setas + OK
- Dino: OK pula; BACK volta ao menu
- Cobrinha: setas; BACK volta ao menu
