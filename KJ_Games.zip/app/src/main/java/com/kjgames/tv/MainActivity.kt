package com.kjgames.tv

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.content.Context
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var game: GameView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        game = GameView(this)
        setContentView(game)
        game.isFocusable = true
        game.requestFocus()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (game.handleKey(keyCode)) return true
        return super.onKeyDown(keyCode, event)
    }
    override fun onResume() { super.onResume(); game.resume() }
    override fun onPause() { game.pause(); super.onPause() }
}

private class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mode = 0 // menu, dino, snake
    private var selected = 0
    private var dinoY = 0f
    private var velocity = 0f
    private var obstacleX = 0f
    private var dinoScore = 0
    private var snake = mutableListOf<Pair<Int,Int>>()
    private var direction = Pair(1,0)
    private var food = Pair(12,8)
    private var snakeScore = 0
    private var lastTime = 0L
    private var running = true
    private val cols = 24
    private val rows = 14
    private val ground = 0.78f

    init { setBackgroundColor(Color.rgb(16,24,39)); resetDino(); resetSnake() }
    fun resume() { running = true; lastTime = 0; invalidate() }
    fun pause() { running = false }
    fun handleKey(code: Int): Boolean {
        when (mode) {
            0 -> when(code) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT -> { selected = (selected+1)%2; invalidate(); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT -> { selected = (selected+1)%2; invalidate(); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    mode = if(selected==0) 1 else 2
                    resetDino(); resetSnake(); invalidate(); return true
                }
            }
            1 -> when(code) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_SPACE -> { if(dinoY >= 0f) velocity = -height*0.85f; return true }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> { mode=0; invalidate(); return true }
            }
            2 -> when(code) {
                KeyEvent.KEYCODE_DPAD_UP -> { if(direction.second!=1) direction=Pair(0,-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { if(direction.second!=-1) direction=Pair(0,1); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { if(direction.first!=1) direction=Pair(-1,0); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { if(direction.first!=-1) direction=Pair(1,0); return true }
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> { mode=0; invalidate(); return true }
            }
        }
        return false
    }
    private fun resetDino() { dinoY=0f; velocity=0f; obstacleX=width.toFloat()+100; dinoScore=0 }
    private fun resetSnake() { snake= mutableListOf(Pair(8,7),Pair(7,7),Pair(6,7)); direction=Pair(1,0); snakeScore=0; spawnFood() }
    private fun spawnFood() { food=Pair(Random.nextInt(cols),Random.nextInt(rows)) }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        p.color=Color.rgb(16,24,39); c.drawColor(p.color)
        if(mode==0) { drawMenu(c,w,h); return }
        if(mode==1) drawDino(c,w,h) else drawSnake(c,w,h)
        if(running) postInvalidateDelayed(16)
    }
    private fun drawMenu(c:Canvas,w:Float,h:Float) {
        text(c,"KJ GAMES",w/2,h*.22f,h*.10f,Color.WHITE,true)
        val labels=listOf("JOGO DO DINOSSAURO","JOGO DA COBRINHA")
        labels.forEachIndexed { i,s ->
            val r=RectF(w*.20f,h*(.38f+i*.20f),w*.80f,h*(.52f+i*.20f))
            p.color=if(i==selected) Color.rgb(56,189,248) else Color.rgb(35,48,68); c.drawRoundRect(r,20f,20f,p)
            text(c,s,w/2,r.centerY()+h*.018f,h*.045f,Color.WHITE,true)
        }
        text(c,"Use as setas e OK do controle",w/2,h*.88f,h*.035f,Color.LTGRAY,false)
    }
    private fun drawDino(c:Canvas,w:Float,h:Float) {
        val floor=h*ground
        p.color=Color.rgb(190,200,210); c.drawLine(0f,floor,w,floor,p)
        val size=h*.10f; val x=w*.16f
        dinoY += velocity*.016f
        velocity += h*2.1f*.016f
        if(dinoY>0f){dinoY=0f;velocity=0f}
        p.color=Color.rgb(56,189,248)
        c.drawRoundRect(x,floor-size+dinoY,x+size,floor+dinoY,12f,12f,p)
        obstacleX -= w*.006f
        if(obstacleX < -h*.07f){obstacleX=w+Random.nextInt(150,500);dinoScore++}
        p.color=Color.rgb(34,197,94)
        c.drawRect(obstacleX,floor-h*.09f,obstacleX+h*.045f,floor,p)
        if(obstacleX<x+size && obstacleX+h*.045f>x && dinoY > -h*.055f) {
            text(c,"Fim de jogo! Pressione OK para reiniciar",w/2,h*.35f,h*.045f,Color.WHITE,true)
            velocity=0f; obstacleX=w+Random.nextInt(250,700)
        }
        text(c,"DINOSSAURO   •   PONTOS: $dinoScore",w/2,h*.12f,h*.045f,Color.WHITE,true)
        text(c,"OK = PULAR     BACK = MENU",w/2,h*.94f,h*.03f,Color.LTGRAY,false)
    }
    private var snakeTick=0
    private fun drawSnake(c:Canvas,w:Float,h:Float) {
        val cellW=w/cols; val cellH=h/rows
        snakeTick++
        if(snakeTick%9==0) {
            val head=snake.first()
            val next=Pair(head.first+direction.first,head.second+direction.second)
            if(next.first !in 0 until cols || next.second !in 0 until rows || next in snake) {
                resetSnake()
            } else {
                snake.add(0,next)
                if(next==food){snakeScore++;spawnFood()} else snake.removeAt(snake.lastIndex)
            }
        }
        p.color=Color.rgb(248,113,113)
        c.drawRoundRect(food.first*cellW+3,food.second*cellH+3,(food.first+1)*cellW-3,(food.second+1)*cellH-3,8f,8f,p)
        p.color=Color.rgb(34,197,94)
        snake.forEach { (x,y)-> c.drawRoundRect(x*cellW+2,y*cellH+2,(x+1)*cellW-2,(y+1)*cellH-2,8f,8f,p) }
        text(c,"COBRINHA   •   PONTOS: $snakeScore",w/2,h*.07f,h*.04f,Color.WHITE,true)
        text(c,"SETAS = MOVER     BACK = MENU",w/2,h*.96f,h*.028f,Color.LTGRAY,false)
    }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean) {
        p.color=color; p.textSize=size; p.textAlign=Paint.Align.CENTER; p.typeface=if(bold) android.graphics.Typeface.create("sans-serif",1) else android.graphics.Typeface.create("sans-serif",0)
        c.drawText(s,x,y,p)
    }
}
